from more_interfaces.msg._address_book import AddressBook  # noqa: F401

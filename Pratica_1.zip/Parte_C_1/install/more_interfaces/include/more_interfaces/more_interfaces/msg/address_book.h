// generated from rosidl_generator_c/resource/idl.h.em
// with input from more_interfaces:msg/AddressBook.idl
// generated code does not contain a copyright notice

#ifndef MORE_INTERFACES__MSG__ADDRESS_BOOK_H_
#define MORE_INTERFACES__MSG__ADDRESS_BOOK_H_

#include "more_interfaces/msg/detail/address_book__struct.h"
#include "more_interfaces/msg/detail/address_book__functions.h"
#include "more_interfaces/msg/detail/address_book__type_support.h"

#endif  // MORE_INTERFACES__MSG__ADDRESS_BOOK_H_

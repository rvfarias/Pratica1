// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from more_interfaces:msg/AddressBook.idl
// generated code does not contain a copyright notice

#ifndef MORE_INTERFACES__MSG__DETAIL__ADDRESS_BOOK__TYPE_SUPPORT_HPP_
#define MORE_INTERFACES__MSG__DETAIL__ADDRESS_BOOK__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "more_interfaces/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_more_interfaces
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  more_interfaces,
  msg,
  AddressBook
)();
#ifdef __cplusplus
}
#endif

#endif  // MORE_INTERFACES__MSG__DETAIL__ADDRESS_BOOK__TYPE_SUPPORT_HPP_

#ifndef POLYGON_PLUGINS__POLYGON_PLUGINS_HPP_
#define POLYGON_PLUGINS__POLYGON_PLUGINS_HPP_

#include "polygon_plugins/visibility_control.h"

namespace polygon_plugins
{

class PolygonPlugins
{
public:
  PolygonPlugins();

  virtual ~PolygonPlugins();
};

}  // namespace polygon_plugins

#endif  // POLYGON_PLUGINS__POLYGON_PLUGINS_HPP_
